#!/bin/sh

helm -n towardsf5gc delete ueransim

#k9s -n towardsf5gc

