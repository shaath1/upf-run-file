#!/bin/sh

helm -n towardsf5gc install tf5gc ./free5gc/
