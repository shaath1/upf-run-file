#!/bin/sh

helm -n towardsf5gc delete tf5gc


