# free5gc-sba core installation                      
## Perform this instructions on jumphost 

### Install kubectl
```bash
sudo snap install kubectl --classic
```
### Install helm
```bash
sudo snap install helm --classic
```
#### Install kubectl
```bash
curl -sS https://webinstall.dev/k9s | bash
source ~/.config/envman/PATH.env
```
### Install krew
```bash
(
  set -x; cd "$(mktemp -d)" &&
  OS="$(uname | tr '[:upper:]' '[:lower:]')" &&
  ARCH="$(uname -m | sed -e 's/x86_64/amd64/' -e 's/\(arm\)\(64\)\?.*/\1\2/' -e 's/aarch64$/arm64/')" &&
  KREW="krew-${OS}_${ARCH}" &&
  curl -fsSLO "https://github.com/kubernetes-sigs/krew/releases/latest/download/${KREW}.tar.gz" &&
  tar zxvf "${KREW}.tar.gz" &&
  ./"${KREW}" install krew
)
echo 'export PATH="${KREW_ROOT:-$HOME/.krew}/bin:$PATH"' >> ~/.bashrc 

### Install virt
```bash
kubectl krew install virt
```
 
 
### K8s autocomplete
```bash
echo "source <(kubectl completion bash)" >> ~/.bashrc 
echo "alias k=kubectl" >> ~/.bashrc 
echo "complete -o default -F __start_kubectl k" >> ~/.bashrc 
source ~/.bashrc 
```
### Install nginx
```bash
sudo apt update
sudo apt install nginx
sudo apt --fix-broken install
sudo apt install nginx
```
### Configure K8s settings
```bash
kubectl create namespace towardsf5gc
kubectl config set-context --current --namespace=towardsf5gc
kubectl label nodes node-0 free5gc=sba
```

### Upload virtual machine image
```bash
wget https://cloud-images.ubuntu.com/jammy/current/jammy-server-cloudimg-amd64.img
sudo mv jammy-server-cloudimg-amd64.img /var/www/html/jammy-server-cloudimg-amd64.img
```
### clone the free5gc-sba from the gitlab reporsity (instruction will be added later)



# UE and gNB Setup                                   
## Perform this instructions on UE     
### Install sctp on UE
```bash
sudo apt update
sudo apt install linux-modules-extra-5.15.0-1041-azure
sudo reboot 
```
### Check kernel version should shown as below
```bash
 ubuntu@ubuntu:~$ uname -r
 5.15.0-1041-azure
 sudo modprobe sctp
```
### Install GTP5g
```bash
echo "Installing GTP5g..."
cd ~
git clone -b v0.8.2 https://github.com/free5gc/gtp5g.git
cd gtp5g
make
sudo make install
cd~
```

# UPF Setup.                                       
## Perform this instructions on UPF VM      
```bash
if_addr=$(ip -4 addr show enp1s0 | grep -oP '(?<=inet\s)\d+(\.\d+){3}')
echo "$if_addr"
```
### Prepare network settings for UE
```bash
echo "change to netplan directoy"
cd /etc/netplan
echo "remove current file"
sudo rm 50-cloud-init.yaml
echo "git new file"
sudo curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/50-cloud-init.yaml
sudo chmod 600 50-cloud-init.yaml
echo "done"
sudo netplan apply
ip a
cd ~
```
### Install data plane supporting packages
```bash
echo "Installing data plane supporting packages..."
sudo apt -y update
sudo apt-get -y install git gcc g++ cmake libmnl-dev autoconf libtool libyaml-dev
```
### Install Go
```bash
echo "Installing Go..."
wget https://dl.google.com/go/go1.18.10.linux-amd64.tar.gz
sudo tar -C /usr/local -zxvf go1.18.10.linux-amd64.tar.gz
mkdir -p ~/go/{bin,pkg,src}
echo 'export GOPATH=$HOME/go' >> ~/.bashrc
echo 'export GOROOT=/usr/local/go' >> ~/.bashrc
echo 'export PATH=$PATH:$GOPATH/bin:$GOROOT/bin' >> ~/.bashrc
echo 'export GO111MODULE=auto' >> ~/.bashrc
source ~/.bashrc
cat ~/.bashrc | grep "GO"
```
### Install GTP5g
```bash
echo "Installing GTP5g..."
cd ~
git clone -b v0.8.2 https://github.com/free5gc/gtp5g.git
cd gtp5g
make
sudo make install
cd~
```
### Install UPF (Free5GC)
```bash
echo "Installing UPF (Free5GC)..."
git clone --recursive -b v3.3.0 -j "$(nproc)" https://github.com/free5gc/free5gc.git
cd free5gc/
make upf
cp run.sh run.sh.original
rm run.sh
curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/run.sh
chmod 775 run.sh
cd config
rm upfcfg.yaml
curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/upfcfg.yaml
chmod 664 upfcfg.yaml
curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/modify_upfcfg.sh
chmod u+x modify_upfcfg.sh
./modify_upfcfg.sh
cd ..
echo "Installation complete."
```
### Enable ip forwarding and UE data plane connectity
```bash
sudo apt install iptables-persistent netfilter-persistent
sudo iptables -A FORWARD -j ACCEPT
sudo iptables -t nat -A POSTROUTING -o enp1s0 -j MASQUERADE
sudo netfilter-persistent save
sudo systemctl enable netfilter-persistent
sudo systemctl restart netfilter-persistent
sudo systemctl stop ufw
sudo systemctl disable ufw
cd ~
curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/netforward.sh
chmod u+x netforward.sh
sudo ./netforward.sh
sudo sysctl -w net.ipv4.ip_forward=1
```
### Create upf service startup
```bash
cd ~
curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/upf_start.sh
chmod u+x upf_start.sh
cd /etc/systemd/system/
sudo curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/upf.service
sudo systemctl enable upf.service
sudo systemctl start upf.service
```
### Reboot the system
```bash
sudo reboot 
```
### Make sure everything is ok
```bash
ps -ef | grep run.sh
```
