#!/bin/sh
helm -n towardsf5gc install ueransim ./ueransim/

k9s -n towardsf5gc
