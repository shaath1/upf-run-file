et the network interface
network_interface="uesimtun0"

# Websites to browse
websites=("https://www.f5.com" "https://www.google.com" "https://www.ripe.net")

# Number of times to browse each website
num_iterations=100

# Function to perform browsing
browse_website() {
    local url="$1"
    
    for ((i = 1; i <= num_iterations; i++)); do
        echo "Browsing $url - Attempt $i"
        curl --interface $network_interface -L --max-time 10 "$url"
        echo -e "\n-------------------------------------\n"
        sleep 1
    done
}

# Main loop
for website in "${websites[@]}"; do
    browse_website "$website"
done

