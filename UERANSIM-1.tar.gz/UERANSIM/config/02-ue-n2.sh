#!/bin/sh

#./nr-gnb -c open5gs-gnb.yaml
./nr-ue -c free5gc-ue.yaml
