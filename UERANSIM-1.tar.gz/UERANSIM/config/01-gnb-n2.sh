#!/bin/sh

#./nr-gnb -c open5gs-gnb.yaml
./nr-gnb -c free5gc-gnb.yaml
