#!/bin/bash

# Check if environment variable is set
 if [ -z "$CUSTOMER_NAME" ]; then
    # CUSTOMER_NAME=customer-$(shuf -i 100-999 -n 1)
    echo "Please set CUSTOMER_NAME, using export CUSTOMER_NAME=customer1"
    exit 1
 fi
# Step 1: Create directory
echo "Step 1: Create directory"
mkdir "$CUSTOMER_NAME"

# Step 2: Copy *.tf files to the directory
echo "Step 2: Copy files to the directory"
cp ../$CERT_FILE_NAME  $CUSTOMER_NAME/
cp ../create-appstack-site-demo.tf "$CUSTOMER_NAME"/"$CUSTOMER_NAME-appstack-site.tf"
cp ../create-webui-lb-demo.tf "$CUSTOMER_NAME"/"$CUSTOMER_NAME-webui-lb.tf"
cp ../main.tf "$CUSTOMER_NAME"/"main.tf"
touch variables.tf "$CUSTOMER_NAME"/"variables.tf"

# Step 3: Add a new JSON variable in variables.tf
echo "Step 3: Add a new JSON variable in variables.tf"
echo -e 'variable "namespace" {\n  type    = string\n  default = "towardsf5gc"\n}' >> $CUSTOMER_NAME/variables.tf
echo -e 'variable "tenant" {\n  type    = string\n  default = "'$TENANT_ID'"\n}' >> $CUSTOMER_NAME/variables.tf
echo -e 'variable "api_cert" {\n  type    = string\n  default = "'$CERT_FILE_NAME'"\n}' >> $CUSTOMER_NAME/variables.tf
echo -e 'variable "api_url" {\n  type    = string\n  default = "'$XC_API_URL'"\n}' >> $CUSTOMER_NAME/variables.tf
echo -e 'variable "appstack_sitename" {\n  type    = string\n  default = "tf-appstack-'$CUSTOMER_NAME'"\n}' >> $CUSTOMER_NAME/variables.tf
echo -e 'variable "k8s_cluster" {\n  type    = string\n  default = "tf-k8s-'$CUSTOMER_NAME'"\n}' >> $CUSTOMER_NAME/variables.tf
echo -e 'variable "webui_url" {\n  type    = string\n  default = "tf-web5g-'$CUSTOMER_NAME'.'$WEB_DOMAIN'"\n}' >> $CUSTOMER_NAME/variables.tf
echo -e 'variable "latitude" {\n  type    = string\n  default = "'$LATITUDE'"\n}' >> $CUSTOMER_NAME/variables.tf
echo -e 'variable "longitude" {\n  type    = string\n  default = "'$LONGTITUDE'"\n}' >> $CUSTOMER_NAME/variables.tf

# Step 4: create-appstack-site-demo.tf
echo "Step 4: create $CUSTOMER_NAME-appstack-site.tf"
sed -i 's/tf-appstack-site/tf-appstack-site-'$CUSTOMER_NAME'/g' "$CUSTOMER_NAME/$CUSTOMER_NAME-appstack-site.tf"
sed -i 's/tf-k8s-cluster-v/tf-k8s-'$CUSTOMER_NAME'/g' "$CUSTOMER_NAME/$CUSTOMER_NAME-appstack-site.tf"
sed -i 's/tf-k8s-cluster-v/tf-k8s-'$CUSTOMER_NAME'/g' "$CUSTOMER_NAME/$CUSTOMER_NAME-webui-lb.tf"
sed -i 's/tf-appstack-site/tf-appstack-site-'$CUSTOMER_NAME'/g' "$CUSTOMER_NAME/$CUSTOMER_NAME-webui-lb.tf"

# Step 5: create-webui-lb-demo.tf
echo "Step 5: create $CUSTOMER_NAME-webui-lb.tf"
sed -i 's/tf-free5gc-webui-pool/tf-pool-'$CUSTOMER_NAME'/g' "$CUSTOMER_NAME/$CUSTOMER_NAME-webui-lb.tf"
sed -i 's/tf-free5gc-waf/tf-waf-'$CUSTOMER_NAME'/g' "$CUSTOMER_NAME/$CUSTOMER_NAME-webui-lb.tf"
sed -i 's/tf-free5gc-lb-v/tf-lb-'$CUSTOMER_NAME'/g' "$CUSTOMER_NAME/$CUSTOMER_NAME-webui-lb.tf"

# Display success message
echo "Setup for $CUSTOMER_NAME completed successfully!"
# Step 6: execute terraform
current_directory=$(pwd)
echo "Current Working Dir"
ls -alh
ls $CUSTOMER_NAME -alh