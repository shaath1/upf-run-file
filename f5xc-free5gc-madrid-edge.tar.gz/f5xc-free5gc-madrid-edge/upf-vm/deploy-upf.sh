#!/bin/bash

# Step 1: Create directory
echo "Step 1: Create directory"
mkdir "$CUSTOMER_NAME"

# Step 2: Copy files to the directory
echo "Step 2: Copy files to the directory"
cp net-attach.yaml "$CUSTOMER_NAME"/net-attach.yaml
cp upf-configmap.yaml "$CUSTOMER_NAME"/upf-configmap.yaml
cp upf.yaml "$CUSTOMER_NAME"/upf.yaml

# Step 3: modify ip addresses
echo "Step 3: modify ip addresses"
sed -i 's/10.1.130.70/'"$N3_UPF"'/g' "$CUSTOMER_NAME"/net-attach.yaml
sed -i 's/10.1.160.70/'"$N6_UPF"'/g' "$CUSTOMER_NAME"/net-attach.yaml
sed -i 's/10.1.130.70/'"$N3_UPF"'/g' "$CUSTOMER_NAME"/upf-configmap.yaml
sed -i 's/10.99.0.0/'"$UE_SUBNET"'/g' "$CUSTOMER_NAME"/upf-configmap.yaml

# Step 4: configure CE
echo "Step 4: configure CE"
kubectl apply -f $CUSTOMER_NAME/net-attach.yaml
kubectl apply -f $CUSTOMER_NAME/upf-configmap.yaml
kubectl apply -f $CUSTOMER_NAME/upf.yaml

# Display success message
echo "Setup for $CUSTOMER_NAME completed successfully!"