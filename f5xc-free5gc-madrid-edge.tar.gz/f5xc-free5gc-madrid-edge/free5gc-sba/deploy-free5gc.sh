#!/bin/bash

# Step 1: Create directory
echo "Step 1: Create directory"
mkdir "$CUSTOMER_NAME"

# Step 2: Copy files to the directory
echo "Step 2: Copy files to the directory"
cp -R free5gc "$CUSTOMER_NAME"/
cp install-tf5gc.sh "$CUSTOMER_NAME"/


# Step 3: modify ip addresses
echo "Step 3: modify ip addresses"
sed -i 's/10.1.130.70/'"$N3_UPF"'/g' "$CUSTOMER_NAME"/free5gc/charts/free5gc-smf/values.yaml
sed -i 's/10.99.0.0/'"$UE_SUBNET"'/g' "$CUSTOMER_NAME"/free5gc/charts/free5gc-smf/values.yaml
sed -i 's/10.1.120.101/'"$N2_AMF"'/g' "$CUSTOMER_NAME"/free5gc/values.yaml
sed -i 's/10.1.140.101/'"$N4_SMF"'/g' "$CUSTOMER_NAME"/free5gc/values.yaml

# Step 4: install free5gc
echo "Step 4: install free5gc"
cd $CUSTOMER_NAME
./install-tf5gc.sh


# Display success message
echo "Setup for $CUSTOMER_NAME completed successfully!"