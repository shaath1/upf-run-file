# Overview

![Alt text](images/overview.png)

# App Stack Site setup (API Method)
## Create Access Token
1.	Lets create API token, go to home clicking F5 icon. And then select administration

<div align="left">
  <img src="images/access-token-1.png" alt="Image 1" width="400"/>
</div>

2.	Select Credentials:

<div align="left">
  <img src="images/access-token-2.png" alt="Image 1" width="400"/>
</div>

3.  Then, Click Add Credentials, Enter the following variables, and click Generate

    Credential Name	<your-namespace>-api-token
    Credential Type	API Token
    Expiry Date	Select any date
<div align="left">
  <img src="images/access-token-3.png" alt="Image 1" width="400"/>
</div>

4. Save the keys in your Preferred method (must have it to perform next steps)
Very Important, copy the token and save it on notepad 
<div align="left">
  <img src="images/access-token-4.png" alt="Image 1" width="400"/>
</div>
## Connect to F5 Distributed Cloud Developer Portal

1. Go f5.com/cloud -> Resources Drop Down ->  and then select API developer portal
<div align="left">
  <img src="images/dev-1.png" alt="Image 1" width="400"/>
</div>

2. You will be presented to access the API Developer Portal, enter tenant your tenant name for example f5-emea-sp
<div align="left">
  <img src="images/dev-2.png" alt="Image 1" width="400"/>
</div>

3. Click on Authorize on the top right , and add your created API token key, and click authorize
<div align="left">
  <img src="images/dev-4.png" alt="Image 1" width="400"/>
  <img src="images/dev-3.png" alt="Image 1" width="400"/>
</div>

### Configure K8s cluster
1. Search for “k8s cluster” and Click on it (on left side)
<div align="left">
  <img src="images/k8s-1.png" alt="Image 1" width="400"/>
</div>
2. On the API, select the first API which will create k8s configuration specification, and click on try out:
<div align="left">
  <img src="images/k8s-2.png" alt="Image 1" width="400"/>
</div>
3. Configure metadata.namespace with value system, and paste the content of k8s.json from and click execute

curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/k8s.yaml

<div align="left">
  <img src="images/k8s-3.png" alt="Image 1" width="400"/>
</div>

### Create Appstack Site
1. Go to https://f5-emea-sp.console.ves.volterra.io/web/devportal/apidocs/views.voltstack_site
2. if needed authenticate similar to previous method

<div align="left">
  <img src="images/app-stack1.png" alt="Image 1" width="400"/>
</div>

for JSON you can get an example from 
curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/appstack.json

### Create namespace
1. https://f5-emea-sp.console.ves.volterra.io/web/devportal/apidocs/namespace
2. add the following in the BODY (have to the be the same used in the helm install)
```json
{
  "metadata": {
    "name": "towardsf5gc"
  },
  "spec": {}
}
```
3. Click Execute
## Configure CE
1. Configure the CE as the following:

- Token	<from console >
- Cluster Name	as-tc (same name of app stack site )
- Hostname	node-0
- Certified Hardware	kvm-voltstack-combo
- Primary Outside NIC	eth0
- Latitude/Longitude	the location of the CE


## Download Local kubeconfig file
1. Navigate Home > Distributed Apps > towardsf5gc > Managed K8s
<div align="left">
  <img src="images/kconfig-1.png" alt="Image 1" width="400"/>
</div>

# free5gc-sba core installation                      
## Perform this instructions on jumphost 

### Install kubectl
```bash
sudo snap install kubectl --classic
```
### Install helm
```bash
sudo snap install helm --classic
```
#### Install k9s
```bash
curl -sS https://webinstall.dev/k9s | bash
source ~/.config/envman/PATH.env
```
### Install krew
```bash
(
  set -x; cd "$(mktemp -d)" &&
  OS="$(uname | tr '[:upper:]' '[:lower:]')" &&
  ARCH="$(uname -m | sed -e 's/x86_64/amd64/' -e 's/\(arm\)\(64\)\?.*/\1\2/' -e 's/aarch64$/arm64/')" &&
  KREW="krew-${OS}_${ARCH}" &&
  curl -fsSLO "https://github.com/kubernetes-sigs/krew/releases/latest/download/${KREW}.tar.gz" &&
  tar zxvf "${KREW}.tar.gz" &&
  ./"${KREW}" install krew
)
echo 'export PATH="${KREW_ROOT:-$HOME/.krew}/bin:$PATH"' >> ~/.bashrc 
source ~/.bashrc
```
### Install virt
```bash
kubectl krew install virt
```
### K8s autocomplete
```bash
echo "source <(kubectl completion bash)" >> ~/.bashrc 
echo "alias k=kubectl" >> ~/.bashrc 
echo "complete -o default -F __start_kubectl k" >> ~/.bashrc 
source ~/.bashrc 
```
### Install nginx
```bash
sudo apt update
sudo apt install nginx
sudo apt --fix-broken install
sudo apt install nginx
```
### Connect to App Stack K8s
```bash
cd ~
mkdir .kube
cd ~/.kube
```
Copy/Paste the content Local Kubeconfig in .kube/config
```bash
vi config

as shown in the following example:

ubuntu@jump-v3:~$ cat .kube/config 
apiVersion: v1
clusters:
- cluster:
    certificate-authority-data: LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUd5akNDQkxLZ0F3SUJBZ0lRRWtxditEZnFLK2NjMmNPTDBqSUNhekFOQmdrcWhraUc5dzBCQVFzRkFEQ0IKcVRFTE1Ba0dB
    **OUTPUT OMMITED**
    server: https://as-tc.as-tc.local:65443
  name: k8s-as-tc
contexts:
- context:
    cluster: k8s-as-tc
    namespace: towardsf5gc
    user: mo.shaath@f5.com
  name: k8s-as-tc
current-context: k8s-as-tc
kind: Config
preferences: {}
users:
- name: mo.shaath@f5.com
  user:
    client-certificate-data: LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUZPakNDQXlLZ0F3SUJBZ0lRUXRmSk80c1NYUEtLUnM1R3VPRU5UVEFOQmdrcWhraUc5dzBCQVFzRkFEQ0IKdGpFTE1Ba0dBMVVFQmhNQ1ZWTXhFekFSQmdOVkJBZ1RDa05oYkdsbWIzSnVhV0V4RkRBU0JnTlZCQWNUQzFOaApiblJoSUVOc1lYSmhN
   **OUTPUT OMMITED** 
    client-key-data: LS0tLS1CRUdJTiBQUklWQVRFIEtFWS0tLS0tCk1JSUV2UUlCQURBTkJna3Foa2lHOXcwQkFRRUZBQVNDQktjd2dnU2pBZ0VBQW9JQkFRRGhTTTEybUVuL0kwZnYKNzRKVXZPNzEy
    **OUTPUT OMMITED**
ubuntu@jump-v3:~$

```
Add in /etc/hosts CE node IP address (as-tc.as-tc.local) that is referred in the Kubeconfig file as show in the following example
```bash
ubuntu@jump-v3:~/create-vm$ cat /etc/hosts
127.0.0.1 localhost

# The following lines are desirable for IPv6 capable hosts
::1 ip6-localhost ip6-loopback
fe00::0 ip6-localnet
ff00::0 ip6-mcastprefix
ff02::1 ip6-allnodes
ff02::2 ip6-allrouters
ff02::3 ip6-allhost
**10.1.1.4 as-tc.as-tc.local**
ubuntu@jump-v3:~/create-vm$ 
```

Confirm you can connect to App Stack by doing this Command
```bash
ubuntu@jump-v3:~/create-vm$ kubectl get nodes
NAME     STATUS   ROLES        AGE   VERSION
node-0   Ready    ves-master   11d   v1.23.14-ves
ubuntu@jump-v3:~/create-vm$ 
```

### Configure K8s settings
```bash
kubectl create namespace towardsf5gc
kubectl config set-context --current --namespace=towardsf5gc
kubectl label nodes node-0 free5gc=sba
```
### Upload virtual machine image
```bash
wget https://cloud-images.ubuntu.com/jammy/current/jammy-server-cloudimg-amd64.img
sudo mv jammy-server-cloudimg-amd64.img /var/www/html/jammy-server-cloudimg-amd64.img
```
### Install free5gc and run helm chart
you can clone this reprositry or use the below procedure
```bash
git clone git@gitlab.com:shaath/f5xc-free5gc.git
```
```bash
cd ~ 
curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/free5gc-sba.tar.gz
tar -zxvf free5gc-sba.tar.gz
cd free5gc-sba
./install-tf5gc.sh
```
verify all containers are up and running by running k9s

## Connect to webui to free5gc
### you must create the below objects in namespace created earlier (towardsf5gc)
1. Create an Origin pool with the settings like below (note the name of service)

<div align="left">
  <img src="images/webui-1.png" alt="Image 1" width="400"/>
</div>

2. Create HTTP load balancer like the below settings (use the domain registed in your tenant )

<div align="left">
  <img src="images/webui-2.png" alt="Image 1" width="400"/>
</div>

<div align="left">
  <img src="images/webui-3.png" alt="Image 1" width="400"/>
</div>

3. Connect to webui for free5gc
<div align="left">
  <img src="images/webui-4.png" alt="Image 1" width="400"/>
</div>

- Default Username : admin
- Default Password : free5gc

4. Create new subscriber if it is not there (leave default all settings as default)
<div align="left">
  <img src="images/webui-5.png" alt="Image 1" width="400"/>
</div>
<div align="left">
  <img src="images/webui-6.png" alt="Image 1" width="400"/>
</div>


## UPF Setup
## Kubevirt Setup (on Jumphost)
```bash
cd ~
mkdir create-vm
curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/net-attach.yaml
curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/upf-vm4.yaml
if_addr=$(ip -4 addr show ens5 | grep -oP '(?<=inet\s)\d+(\.\d+){3}')
echo "      url: http://$if_addr/jammy-server-cloudimg-amd64.img" >> upf-vm4.yaml
kubectl apply -f net-attach.yaml
kubectl apply -f upf-vm4.yaml
```
it will take VM around 5-10 minutes to boot, to connect to it use the following Command
```bash
kubectl virt console upf-vm4
```
## UPF Virtual Machine Setup
## Perform these instructions on UPF VM  
```bash
if_addr=$(ip -4 addr show enp1s0 | grep -oP '(?<=inet\s)\d+(\.\d+){3}')
echo "$if_addr"
```
### Prepare network settings for UE
```bash
echo "change to netplan directoy"
cd /etc/netplan
echo "remove current file"
sudo rm 50-cloud-init.yaml
echo "git new file"
sudo curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/50-cloud-init.yaml
sudo chmod 600 50-cloud-init.yaml
echo "done"
sudo netplan apply
ip a
cd ~
```
### Install data plane supporting packages
```bash
echo "Installing data plane supporting packages..."
sudo apt -y update
sudo apt-get -y install git gcc g++ cmake libmnl-dev autoconf libtool libyaml-dev
```
### Install Go
```bash
echo "Installing Go..."
wget https://dl.google.com/go/go1.18.10.linux-amd64.tar.gz
sudo tar -C /usr/local -zxvf go1.18.10.linux-amd64.tar.gz
mkdir -p ~/go/{bin,pkg,src}
echo 'export GOPATH=$HOME/go' >> ~/.bashrc
echo 'export GOROOT=/usr/local/go' >> ~/.bashrc
echo 'export PATH=$PATH:$GOPATH/bin:$GOROOT/bin' >> ~/.bashrc
echo 'export GO111MODULE=auto' >> ~/.bashrc
source ~/.bashrc
cat ~/.bashrc | grep "GO"
```
### Install GTP5g
```bash
echo "Installing GTP5g..."
cd ~
git clone -b v0.8.2 https://github.com/free5gc/gtp5g.git
cd gtp5g
make
sudo make install
cd~
```
### Install UPF (Free5GC)
```bash
echo "Installing UPF (Free5GC)..."
git clone --recursive -b v3.3.0 -j "$(nproc)" https://github.com/free5gc/free5gc.git
cd free5gc/
make upf
cp run.sh run.sh.original
rm run.sh
curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/run.sh
chmod 775 run.sh
cd config
rm upfcfg.yaml
curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/upfcfg.yaml
chmod 664 upfcfg.yaml
curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/modify_upfcfg.sh
chmod u+x modify_upfcfg.sh
./modify_upfcfg.sh
cd ..
echo "Installation complete."
```
### Enable ip forwarding and UE data plane connectity
```bash
sudo apt install iptables-persistent netfilter-persistent
sudo iptables -A FORWARD -j ACCEPT
sudo iptables -t nat -A POSTROUTING -o enp1s0 -j MASQUERADE
sudo netfilter-persistent save
sudo systemctl enable netfilter-persistent
sudo systemctl restart netfilter-persistent
sudo systemctl stop ufw
sudo systemctl disable ufw
cd ~
curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/netforward.sh
chmod u+x netforward.sh
sudo ./netforward.sh
sudo sysctl -w net.ipv4.ip_forward=1
```
### Create upf service startup
```bash
cd ~
curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/upf_start.sh
chmod u+x upf_start.sh
cd /etc/systemd/system/
sudo curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/upf.service
sudo systemctl enable upf.service
sudo systemctl start upf.service
```
### Reboot the system
```bash
sudo reboot 
```
### Make sure everything is ok
```bash
ps -ef | grep run.sh
```
# UE and gNB Setup                                   
## Perform this instructions on UE   
### Configure networking
```bash
echo "change to netplan directoy"
cd /etc/netplan
echo "git new file"
sudo curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/51-cloud-init-ue.yaml
sudo chmod 600 50-cloud-init.yaml
sudo chmod 600 51-cloud-init-ue.yaml
echo "done"
sudo netplan apply
ip a
cd ~
```

### Install sctp on UE
```bash
sudo apt update
sudo apt-get -y install linux-modules-extra-5.15.0-1041-azure
sudo reboot 
### Check kernel version should shown as below
```bash
 ubuntu@ubuntu:~$ uname -r
 5.15.0-1041-azure
```
### Install additional packages needed
```bash
sudo apt-get -y install linux-headers-$(uname -r)
sudo apt-get -y install git gcc g++ cmake libmnl-dev autoconf libtool libyaml-dev libsctp-dev
```

### Install GTP5g
```bash
echo "Installing GTP5g..."
cd ~
git clone https://github.com/free5gc/gtp5g.git
cd gtp5g
make
sudo make install
cd ~
```
### Download UE and gNB 
```bash
curl -O https://raw.githubusercontent.com/shaath1/upf-run-file/main/UERANSIM.tar.gz
tar -zxvf UERANSIM.tar.gz
```
# Testing
on UE open three terminals
## Terminal 1 run gNB
```bash
cd UERANSIM/config
./01-gnb-n2.sh

Expected output should be like this:
ubuntu@UE:~/UERANSIM/config$ ./01-gnb-n2.sh 
UERANSIM v3.2.6
[2023-11-25 20:29:01.396] [sctp] [info] Trying to establish SCTP connection... (10.1.120.101:38412)
[2023-11-25 20:29:01.401] [sctp] [info] SCTP connection established (10.1.120.101:38412)
[2023-11-25 20:29:01.402] [sctp] [debug] SCTP association setup ascId[5]
[2023-11-25 20:29:01.402] [ngap] [debug] Sending NG Setup Request
[2023-11-25 20:29:01.404] [ngap] [debug] NG Setup Response received
[2023-11-25 20:29:01.405] [ngap] [info] NG Setup procedure is successful
```
## Terminal 2 run UE
```bash
cd UERANSIM/config
sudo ./02-ue-n2.sh 
Expected output should be like this:
ubuntu@UE:~/UERANSIM/config$ sudo ./02-ue-n2.sh 
UERANSIM v3.2.6
[2023-11-25 20:30:48.213] [nas] [info] UE switches to state [MM-DEREGISTERED/PLMN-SEARCH]
[2023-11-25 20:30:48.214] [rrc] [debug] New signal detected for cell[1], total [1] cells in coverage
[2023-11-25 20:30:48.214] [nas] [info] Selected plmn[208/93]
[2023-11-25 20:30:48.214] [rrc] [info] Selected cell plmn[208/93] tac[1] category[SUITABLE]
[2023-11-25 20:30:48.214] [nas] [info] UE switches to state [MM-DEREGISTERED/PS]
[2023-11-25 20:30:48.214] [nas] [info] UE switches to state [MM-DEREGISTERED/NORMAL-SERVICE]
[2023-11-25 20:30:48.214] [nas] [debug] Initial registration required due to [MM-DEREG-NORMAL-SERVICE]
[2023-11-25 20:30:48.214] [nas] [debug] UAC access attempt is allowed for identity[0], category[MO_sig]
[2023-11-25 20:30:48.214] [nas] [debug] Sending Initial Registration
[2023-11-25 20:30:48.214] [rrc] [debug] Sending RRC Setup Request
[2023-11-25 20:30:48.214] [nas] [info] UE switches to state [MM-REGISTER-INITIATED]
[2023-11-25 20:30:48.215] [rrc] [info] RRC connection established
[2023-11-25 20:30:48.215] [rrc] [info] UE switches to state [RRC-CONNECTED]
[2023-11-25 20:30:48.215] [nas] [info] UE switches to state [CM-CONNECTED]
[2023-11-25 20:30:48.289] [nas] [debug] Authentication Request received
[2023-11-25 20:30:48.314] [nas] [debug] Security Mode Command received
[2023-11-25 20:30:48.314] [nas] [debug] Selected integrity[2] ciphering[0]
[2023-11-25 20:30:48.349] [nas] [debug] Registration accept received
[2023-11-25 20:30:48.349] [nas] [info] UE switches to state [MM-REGISTERED/NORMAL-SERVICE]
[2023-11-25 20:30:48.349] [nas] [debug] Sending Registration Complete
[2023-11-25 20:30:48.349] [nas] [info] Initial Registration is successful
[2023-11-25 20:30:48.349] [nas] [debug] Sending PDU Session Establishment Request
[2023-11-25 20:30:48.349] [nas] [debug] UAC access attempt is allowed for identity[0], category[MO_sig]
[2023-11-25 20:30:48.740] [nas] [debug] PDU Session Establishment Accept received
[2023-11-25 20:30:48.741] [nas] [info] PDU Session establishment is successful PSI[1]
[2023-11-25 20:30:48.761] [app] [info] Connection setup for PDU session[1] is successful, TUN interface[uesimtun0, 10.99.0.6] is up.
```
## Terminal 3 test data plane

While UE and gNB are running 

```bash
ping -I uesimtun0 8.8.8.8 -c 1

ubuntu@UE:~$ ping -I uesimtun0 8.8.8.8 -c 1
PING 8.8.8.8 (8.8.8.8) from 10.99.0.6 uesimtun0: 56(84) bytes of data.
64 bytes from 8.8.8.8: icmp_seq=1 ttl=112 time=5.80 ms

--- 8.8.8.8 ping statistics ---
1 packets transmitted, 1 received, 0% packet loss, time 0ms
rtt min/avg/max/mdev = 5.795/5.795/5.795/0.000 ms
ubuntu@UE:~$
```
```bash
curl --interface uesimtun0 google.com

ubuntu@UE:~$ curl --interface uesimtun0 google.com
<HTML><HEAD><meta http-equiv="content-type" content="text/html;charset=utf-8">
<TITLE>301 Moved</TITLE></HEAD><BODY>
<H1>301 Moved</H1>
The document has moved
<A HREF="http://www.google.com/">here</A>.
</BODY></HTML>
ubuntu@UE:~$ 
```

